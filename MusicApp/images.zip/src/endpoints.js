export const loginUrl = 'http://localhost:3030/users/login';
export const registerUrl = 'http://localhost:3030/users/register';
export const logoutUrl = 'http://localhost:3030/users/logout';